package com.gamespace.app

import android.app.Activity
import android.app.AlertDialog
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.parseColor("#0D0F1A")
    private val card = Color.parseColor("#181B2E")
    private val accent = Color.parseColor("#00E5A0")
    private var pendingPkg: String? = null
    private var games: List<ApplicationInfo> = emptyList()
    private lateinit var adapter: BaseAdapter

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(14).toFloat()
        return g
    }

    private fun button(text: String, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(Color.WHITE)
        b.background = round(card)
        b.minHeight = 0
        b.minimumHeight = 0
        b.minWidth = 0
        b.minimumWidth = 0
        b.setPadding(dp(14), dp(8), dp(14), dp(8))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun toggle(label: String, key: String, onChange: (Boolean) -> Unit): Switch {
        val s = Switch(this)
        s.text = label
        s.setTextColor(Color.WHITE)
        s.textSize = 14f
        s.setPadding(0, dp(9), 0, dp(9))
        s.isChecked = Store.flag(this, key)
        s.setOnCheckedChangeListener { _, c ->
            Store.setFlag(this, key, c)
            onChange(c)
        }
        return s
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(bg)
        root.setPadding(dp(16), dp(40), dp(16), dp(8))

        val header = LinearLayout(this)
        header.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "GAME SPACE"
        title.setTextColor(accent)
        title.textSize = 24f
        title.setTypeface(title.typeface, Typeface.BOLD)
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val gap = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        gap.leftMargin = dp(8)
        header.addView(button("+ Add") { showAdd() }, gap)
        header.addView(button("Stop") { stopMode() }, gap)
        root.addView(header)

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.background = round(card)
        panel.setPadding(dp(14), dp(6), dp(14), dp(6))
        panel.addView(toggle("Do Not Disturb while gaming", "dnd") { on ->
            val nm = getSystemService(NotificationManager::class.java)
            if (on && !nm.isNotificationPolicyAccessGranted) {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
            }
        })
        panel.addView(toggle("Free up RAM", "ram") { })
        panel.addView(toggle("Network boost (Wi-Fi lock + live ping)", "net") { })
        panel.addView(toggle("Pause other apps' internet", "vpn") { })
        val panelLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        panelLp.topMargin = dp(14)
        root.addView(panel, panelLp)

        val empty = TextView(this)
        empty.text = "No games found.\nTap + Add to pick apps."
        empty.setTextColor(Color.GRAY)
        empty.gravity = Gravity.CENTER
        root.addView(empty, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))

        val grid = GridView(this)
        grid.numColumns = 3
        grid.verticalSpacing = dp(10)
        grid.horizontalSpacing = dp(10)
        grid.selector = ColorDrawable(Color.TRANSPARENT)
        adapter = object : BaseAdapter() {
            override fun getCount() = games.size
            override fun getItem(position: Int): Any = games[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val ai = games[position]
                val pm = packageManager
                val cell = LinearLayout(this@MainActivity)
                cell.orientation = LinearLayout.VERTICAL
                cell.gravity = Gravity.CENTER_HORIZONTAL
                cell.setPadding(dp(4), dp(12), dp(4), dp(12))
                cell.background = round(card)

                val icon = ImageView(this@MainActivity)
                icon.setImageDrawable(pm.getApplicationIcon(ai))
                cell.addView(icon, LinearLayout.LayoutParams(dp(56), dp(56)))

                val name = TextView(this@MainActivity)
                name.text = pm.getApplicationLabel(ai).toString()
                name.setTextColor(Color.WHITE)
                name.textSize = 12f
                name.maxLines = 1
                name.ellipsize = TextUtils.TruncateAt.END
                name.gravity = Gravity.CENTER
                cell.addView(name)

                val t = Store.played(this@MainActivity, ai.packageName)
                val played = TextView(this@MainActivity)
                played.text = if (t < 60000L) "Not played yet" else "${t / 3600000}h ${(t / 60000) % 60}m"
                played.setTextColor(accent)
                played.textSize = 10f
                cell.addView(played)
                return cell
            }
        }
        grid.adapter = adapter
        grid.emptyView = empty
        grid.setOnItemClickListener { _, _, pos, _ -> launch(games[pos].packageName) }
        val gridLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        gridLp.topMargin = dp(16)
        root.addView(grid, gridLp)

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        games = loadGames()
        adapter.notifyDataSetChanged()
    }

    @Suppress("DEPRECATION")
    private fun isGame(ai: ApplicationInfo): Boolean =
        ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0

    private fun launcherApps(): List<ApplicationInfo> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .map { it.activityInfo.applicationInfo }
            .filter { it.packageName != packageName }
            .distinctBy { it.packageName }
    }

    private fun loadGames(): List<ApplicationInfo> {
        val pm = packageManager
        val manual = Store.manual(this)
        return launcherApps()
            .filter { isGame(it) || it.packageName in manual }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
    }

    private fun showAdd() {
        val pm = packageManager
        val apps = launcherApps()
            .filter { !isGame(it) }
            .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
        val manual = Store.manual(this)
        val names = apps.map { pm.getApplicationLabel(it).toString() }.toTypedArray()
        val checked = BooleanArray(apps.size) { apps[it].packageName in manual }
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Pick apps to treat as games")
            .setMultiChoiceItems(names, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Save") { _, _ ->
                val s = HashSet<String>()
                for (k in apps.indices) if (checked[k]) s.add(apps[k].packageName)
                Store.setManual(this, s)
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun launch(pkg: String) {
        val wantVpn = Store.flag(this, "vpn")
        if (wantVpn) {
            val consent = VpnService.prepare(this)
            if (consent != null) {
                pendingPkg = pkg
                startActivityForResult(consent, 77)
                return
            }
        }
        go(pkg, wantVpn)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 77) {
            val p = pendingPkg ?: return
            pendingPkg = null
            val ok = resultCode == RESULT_OK
            if (!ok) Toast.makeText(this, "Internet pause skipped (permission denied)", Toast.LENGTH_SHORT).show()
            go(p, ok)
        }
    }

    private fun go(pkg: String, vpn: Boolean) {
        val svc = Intent(this, GameBoostService::class.java)
            .putExtra("game", pkg)
            .putExtra("vpn", vpn)
            .putExtra("dnd", Store.flag(this, "dnd"))
            .putExtra("ram", Store.flag(this, "ram"))
            .putExtra("net", Store.flag(this, "net"))
        startForegroundService(svc)
        val launchIntent = packageManager.getLaunchIntentForPackage(pkg)
        if (launchIntent != null) startActivity(launchIntent)
    }

    private fun stopMode() {
        startService(Intent(this, GameBoostService::class.java).setAction(GameBoostService.ACTION_STOP))
        Toast.makeText(this, "Game mode stopped", Toast.LENGTH_SHORT).show()
    }
}
