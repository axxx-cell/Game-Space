package com.gamespace.app

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Icon
import android.net.wifi.WifiManager
import android.os.Build
import android.os.IBinder
import java.net.InetSocketAddress
import java.net.Socket

class GameBoostService : Service() {
    companion object {
        const val ACTION_STOP = "com.gamespace.app.STOP"
        private const val CHANNEL = "gamespace"
        private const val NOTE_ID = 1
    }

    private val locks = ArrayList<WifiManager.WifiLock>()
    @Volatile private var running = false
    private var cleaned = true
    private var prevFilter = -1
    private var game = ""
    private var startedAt = 0L
    private var vpnOn = false
    @Volatile private var pingText = "Measuring ping..."

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            cleanup()
            stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }
        cleanup()

        game = intent.getStringExtra("game") ?: ""
        val ram = intent.getBooleanExtra("ram", true)
        val dnd = intent.getBooleanExtra("dnd", false)
        val net = intent.getBooleanExtra("net", true)
        vpnOn = intent.getBooleanExtra("vpn", false)

        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Game mode", NotificationManager.IMPORTANCE_LOW)
        )
        startForeground(NOTE_ID, note())

        running = true
        cleaned = false
        startedAt = System.currentTimeMillis()

        if (dnd && nm.isNotificationPolicyAccessGranted) {
            prevFilter = nm.currentInterruptionFilter
            nm.setInterruptionFilter(NotificationManager.INTERRUPTION_FILTER_PRIORITY)
        }
        if (ram) Thread { freeRam() }.start()
        if (net) {
            acquireLocks()
            startPing()
        }
        if (vpnOn) {
            startService(Intent(this, GameVpnService::class.java).putExtra("game", game))
        }
        return START_NOT_STICKY
    }

    private fun note(): Notification {
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, GameBoostService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val extra = if (vpnOn) " | other apps paused" else ""
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Game Space is on")
            .setContentText(pingText + extra)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "Stop", stop
                ).build()
            )
            .build()
    }

    private fun freeRam() {
        val am = getSystemService(ActivityManager::class.java)
        for (ai in packageManager.getInstalledApplications(0)) {
            if (ai.packageName == game || ai.packageName == packageName) continue
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            try { am.killBackgroundProcesses(ai.packageName) } catch (e: Exception) { }
        }
    }

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        try {
            val l = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "gs-perf")
            l.setReferenceCounted(false)
            l.acquire()
            locks.add(l)
        } catch (e: Exception) { }
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val l = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "gs-lat")
                l.setReferenceCounted(false)
                l.acquire()
                locks.add(l)
            } catch (e: Exception) { }
        }
    }

    private fun startPing() {
        Thread {
            val nm = getSystemService(NotificationManager::class.java)
            while (running) {
                val t = System.nanoTime()
                val ms = try {
                    Socket().use { it.connect(InetSocketAddress("1.1.1.1", 443), 1500) }
                    (System.nanoTime() - t) / 1_000_000
                } catch (e: Exception) { -1L }
                pingText = if (ms >= 0) "Ping $ms ms" else "No connection"
                if (running) nm.notify(NOTE_ID, note())
                try { Thread.sleep(2500) } catch (e: InterruptedException) { break }
            }
        }.start()
    }

    private fun cleanup() {
        if (cleaned) return
        cleaned = true
        running = false
        for (l in locks) {
            try { if (l.isHeld) l.release() } catch (e: Exception) { }
        }
        locks.clear()
        if (prevFilter != -1) {
            try {
                getSystemService(NotificationManager::class.java).setInterruptionFilter(prevFilter)
            } catch (e: Exception) { }
            prevFilter = -1
        }
        if (vpnOn) {
            stopService(Intent(this, GameVpnService::class.java))
            vpnOn = false
        }
        if (game.isNotEmpty() && startedAt > 0) {
            Store.addPlayed(this, game, System.currentTimeMillis() - startedAt)
        }
        startedAt = 0
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }
}
