package com.gamespace.app

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream

/**
 * Local "black hole" VPN. Every installed user app EXCEPT the game (and Game Space)
 * is routed into this tunnel and dropped, so the game gets the whole connection.
 */
class GameVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    @Volatile private var alive = false

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val game = intent?.getStringExtra("game") ?: ""
        closeTun()

        val b = Builder()
            .setSession("Game Space")
            .addAddress("10.77.0.2", 32)
            .addAddress("fd00:77::2", 128)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)

        var count = 0
        for (ai in packageManager.getInstalledApplications(0)) {
            if (ai.packageName == game || ai.packageName == packageName) continue
            val isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
            if (isSystem) continue
            try {
                b.addAllowedApplication(ai.packageName)
                count++
            } catch (e: Exception) { }
        }
        if (count == 0) { stopSelf(); return START_NOT_STICKY }

        val fd = try { b.establish() } catch (e: Exception) { null }
        if (fd == null) { stopSelf(); return START_NOT_STICKY }
        tun = fd
        alive = true
        Thread { drain(fd) }.start()
        return START_NOT_STICKY
    }

    private fun drain(fd: ParcelFileDescriptor) {
        try {
            val input = FileInputStream(fd.fileDescriptor)
            val buf = ByteArray(32767)
            while (alive) {
                if (input.read(buf) < 0) break
            }
        } catch (e: Exception) { }
    }

    private fun closeTun() {
        alive = false
        try { tun?.close() } catch (e: Exception) { }
        tun = null
    }

    override fun onRevoke() {
        closeTun()
        stopSelf()
        super.onRevoke()
    }

    override fun onDestroy() {
        closeTun()
        super.onDestroy()
    }
}
