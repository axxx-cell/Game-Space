package com.gamespace.app

import android.content.Context

object Store {
    private fun p(c: Context) = c.getSharedPreferences("gs", Context.MODE_PRIVATE)

    fun flag(c: Context, k: String): Boolean = p(c).getBoolean(k, k != "dnd")
    fun setFlag(c: Context, k: String, v: Boolean) { p(c).edit().putBoolean(k, v).apply() }

    fun manual(c: Context): MutableSet<String> =
        HashSet(p(c).getStringSet("manual", emptySet()) ?: emptySet<String>())

    fun setManual(c: Context, s: Set<String>) {
        p(c).edit().putStringSet("manual", HashSet(s)).apply()
    }

    fun played(c: Context, pkg: String): Long = p(c).getLong("t_$pkg", 0L)
    fun addPlayed(c: Context, pkg: String, ms: Long) {
        p(c).edit().putLong("t_$pkg", played(c, pkg) + ms).apply()
    }
}
