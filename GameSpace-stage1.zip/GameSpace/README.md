# Game Space
Stage 1: project setup, theme, Page 1 (Game Vault), bottom nav, HelpIcon.
Push to GitHub: the Actions tab builds a debug APK (artifact "GameSpace-debug").
