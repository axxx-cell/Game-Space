package com.gamespace.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0A0F1F)
val Cyan = Color(0xFF00E5FF)
val Purple = Color(0xFF8B5CF6)
val CyanDeep = Color(0xFF06B6D4)
val Glass = Color(0xFF1E293B)
val PillGlass = Color(0xFF2D3748)
val Muted = Color(0xFF94A3B8)
val Subtitle = Color(0xFF7DD3E0)
val HelpBg = Color(0xFF2A2F5A)
val HelpText = Color(0xFFCBD5E1)
val GreenOk = Color(0xFF22C55E)
val BoostBrush = Brush.horizontalGradient(listOf(Purple, CyanDeep))
val ActiveBrush = Brush.horizontalGradient(listOf(Color(0xFF9333EA), CyanDeep))

@Composable
fun GameSpaceTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = Cyan, secondary = Purple, background = Bg, surface = Glass),
        content = content
    )
}
