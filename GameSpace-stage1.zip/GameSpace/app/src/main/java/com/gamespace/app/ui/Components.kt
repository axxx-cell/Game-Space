package com.gamespace.app.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SpaceBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier.background(Bg).drawBehind {
            val step = 48.dp.toPx()
            val line = Color(0xFF00E5FF).copy(alpha = 0.04f)
            var x = 0f
            while (x < size.width) { drawLine(line, Offset(x, 0f), Offset(x, size.height)); x += step }
            var y = 0f
            while (y < size.height) { drawLine(line, Offset(0f, y), Offset(size.width, y)); y += step }
            drawRect(Brush.radialGradient(
                listOf(Purple.copy(alpha = 0.15f), CyanDeep.copy(alpha = 0.08f), Color.Transparent),
                center = Offset(size.width, size.height), radius = size.width * 1.1f))
        },
        content = content
    )
}

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    radius: Dp = 16.dp,
    color: Color = Glass,
    alpha: Float = 0.7f,
    borderAlpha: Float = 0.3f,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(radius)
    Box(
        modifier
            .shadow(8.dp, shape, ambientColor = Cyan, spotColor = Cyan)
            .clip(shape)
            .background(color.copy(alpha = alpha))
            .border(1.dp, Cyan.copy(alpha = borderAlpha), shape),
        content = content
    )
}

/** 16dp circle "?" that opens a bottom sheet with an explanation. */
@Composable
fun HelpIcon(title: String, text: String, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Box(
        modifier.size(16.dp).clip(CircleShape).background(HelpBg).clickable { open = true },
        contentAlignment = Alignment.Center
    ) { Text("?", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
    if (open) {
        ModalBottomSheet(onDismissRequest = { open = false }, containerColor = Glass) {
            Column(Modifier.padding(horizontal = 24.dp).padding(bottom = 32.dp)) {
                Text(title, color = Cyan, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(text, color = HelpText, fontSize = 14.sp)
            }
        }
    }
}
