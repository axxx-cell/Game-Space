package com.gamespace.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import com.gamespace.app.ui.*
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { GameSpaceTheme { GameSpaceApp() } }
    }
}

@Composable
fun GameSpaceApp() {
    val pager = rememberPagerState { 5 }
    val scope = rememberCoroutineScope()
    val tabs = listOf(Icons.Filled.Home, Icons.Filled.BarChart, Icons.Filled.SportsEsports, Icons.Filled.Bolt, Icons.Filled.Search)
    SpaceBackground(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            HorizontalPager(pager, Modifier.weight(1f)) { page ->
                when (page) {
                    0 -> GameVaultPage()
                    1 -> PlaceholderPage("Stats", "Live graphs for FPS, temperature, ping, RAM and battery.")
                    2 -> PlaceholderPage("Tools", "Crosshair, voice changer, screen record, touch blocker, performance mode and network firewall.")
                    3 -> PlaceholderPage("Clutch Sense", "Clutch Sense learns your lag and heat patterns privately on-device. No screen reading, 100% private and offline.")
                    else -> PlaceholderPage("AI Search", "Search builds, tips and the meta.")
                }
            }
            val shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
            Row(
                Modifier.fillMaxWidth().clip(shape).background(Color(0xFF1F2937).copy(alpha = 0.9f))
                    .navigationBarsPadding().height(64.dp),
                horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
            ) {
                tabs.forEachIndexed { i, icon ->
                    val on = pager.currentPage == i
                    val s = RoundedCornerShape(12.dp)
                    Box(
                        Modifier.size(46.dp)
                            .then(if (on) Modifier.shadow(10.dp, s, ambientColor = Cyan, spotColor = Cyan) else Modifier)
                            .clip(s).background(if (on) Cyan.copy(alpha = 0.2f) else Color.Transparent)
                            .clickable { scope.launch { pager.animateScrollToPage(i) } },
                        contentAlignment = Alignment.Center
                    ) { Icon(icon, null, tint = if (on) Cyan else Muted) }
                }
            }
        }
    }
}
