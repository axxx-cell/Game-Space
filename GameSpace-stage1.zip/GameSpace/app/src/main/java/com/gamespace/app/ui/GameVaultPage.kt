package com.gamespace.app.ui

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.gamespace.app.data.Game
import com.gamespace.app.data.GameRepo

@Composable
fun GameVaultPage() {
    val ctx = LocalContext.current
    val repo = remember { GameRepo(ctx) }
    var games by remember { mutableStateOf<List<Game>>(emptyList()) }
    var loaded by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var picker by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }
    LaunchedEffect(reload) { games = repo.games(); loaded = true }

    val shown = games.filter { it.name.contains(query, true) }
    val demo = listOf(Game("", "Mobile Legends", "MOBA"), Game("", "Call of Duty", "FPS"), Game("", "Free Fire", "SURVIVAL"))
    val list = if (loaded && games.isEmpty() && query.isEmpty()) demo else shown

    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(12.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.GpsFixed, null, tint = Cyan, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(8.dp))
                Text("GAME SPACE", color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace, letterSpacing = 2.sp,
                    style = TextStyle(shadow = androidx.compose.ui.graphics.Shadow(Cyan, blurRadius = 24f)))
            }
            Text("Performance  •  Control  •  Boost", color = Subtitle, fontSize = 12.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(16.dp))
            StatsRow()
            Spacer(Modifier.height(12.dp))
            PillsRow()
            Spacer(Modifier.height(12.dp))
            SearchBar(query) { query = it }
            Spacer(Modifier.height(12.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(end = 80.dp)) {
                items(list, key = { it.pkg + it.name }) { GameCard(it, repo) }
            }
        }
        // Add-game FAB
        Box(
            Modifier.align(Alignment.BottomEnd).padding(end = 16.dp, bottom = 12.dp).size(52.dp)
                .shadow(10.dp, CircleShape, ambientColor = Cyan, spotColor = Cyan)
                .clip(CircleShape).background(Glass.copy(alpha = 0.85f))
                .border(1.dp, Cyan.copy(alpha = 0.6f), CircleShape).clickable { picker = true },
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Filled.Add, "Add game", tint = Cyan) }
    }
    if (picker) AppPicker(repo, onDismiss = { picker = false }) { repo.pin(it); reload++; picker = false }
}

@Composable
private fun StatsRow() {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        StatCard(Modifier.weight(1f), Icons.Filled.Memory, "RAM", "6.2 / 8 GB", "75%", progress = 0.75f,
            help = "RAM is the phone's working memory. Lower usage means smoother games.")
        StatCard(Modifier.weight(1f), Icons.Filled.Wifi, "Ping", "24 ms", "Stable", dot = GreenOk,
            help = "Ping is how fast your phone talks to the game server. Under 60 ms is great.")
        StatCard(Modifier.weight(1f), Icons.Filled.Thermostat, "Temp", "38°C", "Optimal",
            help = "Phone temperature. Above 42°C the phone slows itself down to cool off.")
    }
}

@Composable
private fun StatCard(
    modifier: Modifier, icon: ImageVector, label: String, value: String, sub: String,
    progress: Float? = null, dot: Color? = null, help: String
) {
    GlassCard(modifier.height(120.dp)) {
        Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(26.dp))
            Spacer(Modifier.height(4.dp))
            Text(label, color = Subtitle, fontSize = 11.sp)
            Text(value, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (progress != null) {
                    LinearProgressIndicator(progress = { progress }, color = Cyan, trackColor = Color.White.copy(0.1f),
                        modifier = Modifier.weight(1f).height(4.dp).clip(CircleShape))
                    Spacer(Modifier.width(6.dp))
                }
                if (dot != null) Box(Modifier.size(6.dp).clip(CircleShape).background(dot)).also { Spacer(Modifier.width(4.dp)) }
                Text(sub, color = if (dot != null) GreenOk else Subtitle, fontSize = 11.sp)
            }
        }
        HelpIcon(label, help, Modifier.align(Alignment.TopEnd).padding(6.dp).size(12.dp))
    }
}

@Composable
private fun PillsRow() {
    var active by remember { mutableIntStateOf(0) }
    val items = listOf(Icons.Filled.SportsEsports to "Game", Icons.Filled.Shield to "Firewall",
        Icons.Filled.BatteryChargingFull to "Power", Icons.Filled.Notifications to "Alerts")
    Row(verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items.forEachIndexed { i, (icon, name) ->
                val on = i == active
                val shape = RoundedCornerShape(24.dp)
                Row(
                    Modifier.weight(1f).height(48.dp)
                        .then(if (on) Modifier.shadow(10.dp, shape, ambientColor = Purple, spotColor = Cyan) else Modifier)
                        .clip(shape)
                        .background(if (on) ActiveBrush else SolidColor(PillGlass.copy(alpha = 0.8f)))
                        .border(1.dp, Cyan.copy(alpha = if (on) 0.8f else 0.35f), shape)
                        .clickable { active = i },
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
                ) {
                    Icon(icon, null, tint = if (on) Color.White else Cyan, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(3.dp))
                    Text(name, color = Color.White, fontSize = 11.sp, maxLines = 1)
                }
            }
        }
        Spacer(Modifier.width(6.dp))
        HelpIcon("Quick modes",
            "Game Mode = maximum performance.\nFirewall = Signal Focus: 80% of your internet to the game, 20% to chat.\nPower Save = battery modes.\nAlerts = Clutch Sense warnings.")
    }
}

@Composable
private fun SearchBar(value: String, onChange: (String) -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Row(
        Modifier.fillMaxWidth().height(44.dp).clip(shape).background(PillGlass.copy(alpha = 0.8f))
            .border(1.dp, Cyan.copy(alpha = 0.35f), shape).padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Filled.Search, null, tint = Muted, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f)) {
            if (value.isEmpty()) Text("Search games", color = Muted, fontSize = 14.sp)
            BasicTextField(value, onChange, singleLine = true, cursorBrush = SolidColor(Cyan),
                textStyle = TextStyle(color = Color.White, fontSize = 14.sp), modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun GameCard(game: Game, repo: GameRepo) {
    val icon by produceState<androidx.compose.ui.graphics.ImageBitmap?>(null, game.pkg) {
        value = if (game.pkg.isEmpty()) null else kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            repo.icon(game.pkg)?.toBitmap(160, 160)?.asImageBitmap()
        }
    }
    GlassCard(Modifier.width(160.dp).height(220.dp), alpha = 0.8f, borderAlpha = 0.5f) {
        Column(Modifier.fillMaxSize().padding(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                HelpIcon("BOOST", "Tap BOOST to optimize and launch the game with Signal Focus.")
                Box(Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFF7C3AED)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                    Text(game.genre, color = Color.White, fontSize = 10.sp)
                }
            }
            Spacer(Modifier.height(6.dp))
            Box(
                Modifier.fillMaxWidth().height(80.dp).clip(RoundedCornerShape(12.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF312E81), Color(0xFF0E7490)))),
                contentAlignment = Alignment.Center
            ) {
                icon?.let { Image(it, null, Modifier.size(56.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Fit) }
                    ?: Icon(Icons.Filled.SportsEsports, null, tint = Color.White.copy(0.8f), modifier = Modifier.size(36.dp))
            }
            Spacer(Modifier.height(8.dp))
            Text(game.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Text("Optimized • 60 FPS", color = Cyan, fontSize = 11.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.weight(1f))
            Row(
                Modifier.fillMaxWidth().height(36.dp).clip(RoundedCornerShape(18.dp)).background(BoostBrush)
                    .clickable { if (game.pkg.isNotEmpty()) repo.launch(game.pkg) },
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Filled.RocketLaunch, null, tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("BOOST", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppPicker(repo: GameRepo, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    var apps by remember { mutableStateOf<List<Game>>(emptyList()) }
    LaunchedEffect(Unit) { apps = repo.allApps() }
    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Glass) {
        Text("Add a game", color = Cyan, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 24.dp, bottom = 8.dp))
        LazyColumn(Modifier.heightIn(max = 480.dp)) {
            items(apps, key = { it.pkg }) { a ->
                Text(a.name, color = Color.White, fontSize = 15.sp,
                    modifier = Modifier.fillMaxWidth().clickable { onPick(a.pkg) }.padding(horizontal = 24.dp, vertical = 12.dp))
            }
        }
    }
}
