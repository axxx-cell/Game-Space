package com.gamespace.app.data

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.drawable.Drawable
import android.util.LruCache
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class Game(val pkg: String, val name: String, val genre: String)

class GameRepo(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("games", Context.MODE_PRIVATE)
    private val cache = LruCache<String, Game>(100)
    private val keywords = listOf("mlbb", "codm", "wildrift", "farlight", "roblox", "freefire",
        "mobile legends", "call of duty", "free fire", "wild rift", "pubg", "genshin")

    private fun genre(s: String): String = when {
        listOf("legends", "wildrift", "wild rift", "mlbb").any { s.contains(it, true) } -> "MOBA"
        listOf("duty", "codm", "pubg", "farlight").any { s.contains(it, true) } -> "FPS"
        listOf("free fire", "freefire", "roblox").any { s.contains(it, true) } -> "SURVIVAL"
        else -> "GAME"
    }

    private fun launchables() = ctx.packageManager.queryIntentActivities(
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)

    /** Auto-detects games (category GAME or known keywords) plus any the user pinned. Runs on IO. */
    suspend fun games(): List<Game> = withContext(Dispatchers.IO) {
        val pm = ctx.packageManager
        val pinned = prefs.getStringSet("pinned", emptySet()) ?: emptySet()
        launchables().mapNotNull { ri ->
            val pkg = ri.activityInfo.packageName
            val label = ri.loadLabel(pm).toString()
            val isGame = ri.activityInfo.applicationInfo.category == ApplicationInfo.CATEGORY_GAME ||
                keywords.any { pkg.contains(it, true) || label.contains(it, true) } || pkg in pinned
            if (!isGame) null else cache.get(pkg) ?: Game(pkg, label, genre("$pkg $label")).also { cache.put(pkg, it) }
        }.distinctBy { it.pkg }.sortedBy { it.name }
    }

    suspend fun allApps(): List<Game> = withContext(Dispatchers.IO) {
        val pm = ctx.packageManager
        launchables().map { Game(it.activityInfo.packageName, it.loadLabel(pm).toString(), "GAME") }
            .distinctBy { it.pkg }.sortedBy { it.name.lowercase() }
    }

    fun pin(pkg: String) {
        val s = (prefs.getStringSet("pinned", emptySet()) ?: emptySet()).toMutableSet().apply { add(pkg) }
        prefs.edit().putStringSet("pinned", s).apply()
    }

    fun icon(pkg: String): Drawable? = try { ctx.packageManager.getApplicationIcon(pkg) } catch (e: Exception) { null }
    fun launch(pkg: String) { ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { ctx.startActivity(it) } }
}
